const path = require('path');
require('dotenv').config();

const toBool = (val) => val === true || val === 'true';

module.exports = {
  // Session & Authentication
  SESSION_DIR: process.env.SESSION_DIR || path.join(__dirname, 'session'),
  PAIRING_CODE: toBool(process.env.PAIRING_CODE ?? true), // true = 8-digit Pairing Code, false = QR Code
  PHONE_NUMBER: process.env.PHONE_NUMBER || '', // International format without + (e.g. "919876543210")

  // Bot & Owner Metadata (Used for Personal DM Anti-Delete delivery)
  BOT_NAME: process.env.BOT_NAME || 'Hermit-MD',
  OWNER_NAME: process.env.OWNER_NAME || 'Adithyan',
  OWNER_NUMBER: (process.env.OWNER_NUMBER || '919876543210')
    .split(',')
    .map((num) => num.trim().replace(/[^0-9]/g, '')),

  // Operational Settings
  PREFIX: process.env.PREFIX || '.',
  MODE: (process.env.MODE || 'public').toLowerCase(), // 'public' or 'private'
  AUTO_READ: toBool(process.env.AUTO_READ || false),
  AUTO_STATUS_READ: toBool(process.env.AUTO_STATUS_READ ?? true),
  AUTO_STATUS_REACT: toBool(process.env.AUTO_STATUS_REACT ?? true),
  STATUS_EMOJI: process.env.STATUS_EMOJI || '💚',

  // Anti-Delete Settings (Defaults to sending deleted text & media to Owner's Personal DM)
  ANTI_DELETE: toBool(process.env.ANTI_DELETE ?? true),
  ANTI_DELETE_TARGET: (process.env.ANTI_DELETE_TARGET || 'dm').toLowerCase(), // 'dm' = Owner Personal DM, 'chat' = Same Chat

  // "Forwarded Many Times" Auto-Modifier for Every Message You Type
  AUTO_FAKE_FORWARD: toBool(process.env.AUTO_FAKE_FORWARD ?? true),
  FORWARDING_SCORE: parseInt(process.env.FORWARDING_SCORE || '999', 10), // >= 5 triggers "Forwarded many times"

  TIMEZONE: process.env.TIMEZONE || 'Asia/Kolkata',

  // Media & Sticker metadata
  STICKER_PACK: process.env.STICKER_PACK || 'Hermit-MD Bot',
  STICKER_AUTHOR: process.env.STICKER_AUTHOR || 'Adithyan Labs',

  // Logging & Debug
  LOG_LEVEL: process.env.LOG_LEVEL || 'info',
};
