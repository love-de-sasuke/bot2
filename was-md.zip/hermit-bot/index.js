const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  makeCacheableSignalKeyStore,
  Browsers,
  jidNormalizedUser,
} = require('@whiskeysockets/baileys');
const pino = require('pino');
const chalk = require('chalk');
const readline = require('readline');
const fs = require('fs');
const path = require('path');

const config = require('./config');
const { serialize } = require('./lib/serialize');
const { loadPlugins, handleCommand } = require('./lib/plugins');
const {
  db,
  saveDb,
  cacheMessage,
  getCachedMessage,
  botSentIds,
  markBotSent,
  checkSpam,
} = require('./lib/store');
const { runtime } = require('./lib/functions');

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const question = (text) => new Promise((resolve) => rl.question(text, resolve));

if (!fs.existsSync(config.SESSION_DIR)) {
  fs.mkdirSync(config.SESSION_DIR, { recursive: true });
}

const logger = pino({
  level: config.LOG_LEVEL,
  transport: {
    target: 'pino-pretty',
    options: { colorize: true, ignore: 'pid,hostname' },
  },
});

async function startBot() {
  console.log(chalk.cyan.bold('\n================================================='));
  console.log(chalk.green.bold(`  🚀 Launching ${config.BOT_NAME} (21 Unique Features)`));
  console.log(chalk.yellow.bold(`  ⚡ Engine: @whiskeysockets/baileys`));
  console.log(chalk.cyan.bold('=================================================\n'));

  console.log(chalk.blue('📦 Loading modular plugins...'));
  loadPlugins(path.join(__dirname, 'plugins'));
  console.log(chalk.green('✅ All plugins loaded.\n'));

  const { state, saveCreds } = await useMultiFileAuthState(config.SESSION_DIR);
  const { version, isLatest } = await fetchLatestBaileysVersion();
  console.log(chalk.gray(`ℹ️ WhatsApp Web v${version.join('.')} (Latest: ${isLatest})`));

  const sock = makeWASocket({
    version,
    logger,
    printQRInTerminal: !config.PAIRING_CODE,
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, logger),
    },
    browser: Browsers.ubuntu('Chrome'),
    generateHighQualityLinkPreview: true,
    syncFullHistory: false,
  });

  // 8-Digit Pairing Code Flow
  if (config.PAIRING_CODE && !sock.authState.creds.registered) {
    let phoneNumber = config.PHONE_NUMBER;
    if (!phoneNumber) {
      phoneNumber = await question(
        chalk.yellow('📱 Enter your WhatsApp Phone Number (with Country Code, e.g. 919876543210): ')
      );
    }
    phoneNumber = phoneNumber.replace(/[^0-9]/g, '');

    setTimeout(async () => {
      try {
        const code = await sock.requestPairingCode(phoneNumber);
        const formattedCode = code?.match(/.{1,4}/g)?.join('-') || code;
        console.log(
          chalk.black.bgGreen.bold('\n 🔑 YOUR WHATSAPP PAIRING CODE: ') +
            ' ' +
            chalk.white.bgBlue.bold(` ${formattedCode} `) +
            '\n'
        );
      } catch (err) {
        console.error(chalk.red('❌ Failed to request pairing code:'), err.message);
      }
    }, 3000);
  }

  sock.ev.on('creds.update', saveCreds);

  // Connection Lifecycle
  sock.ev.on('connection.update', async (update) => {
    const { connection, lastDisconnect } = update;
    if (connection === 'close') {
      const statusCode = lastDisconnect?.error?.output?.statusCode;
      const shouldReconnect = statusCode !== DisconnectReason.loggedOut;
      if (shouldReconnect) setTimeout(() => startBot(), 5000);
    } else if (connection === 'open') {
      const botNumber = jidNormalizedUser(sock.user.id).split('@')[0];
      console.log(chalk.green.bold(`\n🎉 Connected as @${botNumber} (${config.BOT_NAME})`));
    }
  });

  // ==========================================================================
  // EVENT HOOK: Welcome & Goodbye Group Greeter (Feature #18)
  // ==========================================================================
  sock.ev.on('group-participants.update', async (event) => {
    const { id: groupJid, participants, action } = event;
    try {
      const metadata = await sock.groupMetadata(groupJid);
      for (const userJid of participants) {
        if (action === 'add' && db.welcome[groupJid]) {
          await sock.sendMessage(groupJid, {
            text:
              `👋 *Welcome to ${metadata.subject}, @${userJid.split('@')[0]}!*\n\n` +
              `👥 *Member Count:* ${metadata.participants.length}\n` +
              `📌 Type \`${config.PREFIX}menu\` to explore bot features.`,
            mentions: [userJid],
          });
        } else if (action === 'remove' && db.goodbye[groupJid]) {
          await sock.sendMessage(groupJid, {
            text: `👋 *Goodbye @${userJid.split('@')[0]}!* We'll miss you in *${metadata.subject}*.`,
            mentions: [userJid],
          });
        }
      }
    } catch (e) {
      // Ignore metadata fetch errors
    }
  });

  // ==========================================================================
  // EVENT HOOK: Anti-Delete Recovery to Owner's Personal DM (Feature #2)
  // Recovers deleted texts AND media (images, videos, voice notes, stickers)
  // ==========================================================================
  sock.ev.on('messages.update', async (updates) => {
    if (!db.antidelete.enabled) return;

    for (const update of updates) {
      const protocolMsg = update.update?.message?.protocolMessage;
      const isRevoke = protocolMsg && protocolMsg.type === 0;
      if (!isRevoke) continue;

      const deletedId = protocolMsg.key?.id;
      const original = getCachedMessage(deletedId);
      if (!original || original.fromMe) continue;

      try {
        // Resolve Owner's Personal DM JID
        const ownerNum = (db.antidelete.ownerDmNumber || config.OWNER_NUMBER[0] || '').replace(/[^0-9]/g, '');
        const ownerDmJid = ownerNum
          ? `${ownerNum}@s.whatsapp.net`
          : jidNormalizedUser(sock.user?.id || '');

        const targetJid = db.antidelete.target === 'dm' ? ownerDmJid : original.from;

        let chatTitle = 'Private Chat (DM)';
        if (original.isGroup) {
          try {
            const gMeta = await sock.groupMetadata(original.from);
            chatTitle = `Group: ${gMeta.subject}`;
          } catch {
            chatTitle = `Group (${original.from})`;
          }
        }

        const alertHeader =
          `🗑️ *ANTI-DELETE RECOVERY*\n\n` +
          `• *Sender:* @${original.senderNumber} (${original.pushName})\n` +
          `• *Where:* ${chatTitle}\n` +
          `• *Device:* ${original.device}\n` +
          `• *Time:* ${new Date().toLocaleTimeString()}\n` +
          `${original.body ? `\n💬 *Deleted Message:*\n${original.body}` : ''}`;

        if (original.isMedia) {
          const mediaBuffer = await original.download();
          if (original.type === 'imageMessage') {
            await sock.sendMessage(targetJid, {
              image: mediaBuffer,
              caption: alertHeader,
              mentions: [original.sender],
            });
          } else if (original.type === 'videoMessage') {
            await sock.sendMessage(targetJid, {
              video: mediaBuffer,
              caption: alertHeader,
              mentions: [original.sender],
            });
          } else if (original.type === 'audioMessage') {
            await sock.sendMessage(targetJid, { text: alertHeader, mentions: [original.sender] });
            await sock.sendMessage(targetJid, {
              audio: mediaBuffer,
              mimetype: 'audio/mp4',
              ptt: true,
            });
          } else if (original.type === 'stickerMessage') {
            await sock.sendMessage(targetJid, { text: alertHeader, mentions: [original.sender] });
            await sock.sendMessage(targetJid, { sticker: mediaBuffer });
          } else {
            await sock.sendMessage(targetJid, {
              document: mediaBuffer,
              mimetype: 'application/octet-stream',
              fileName: 'recovered_deleted_file',
              caption: alertHeader,
              mentions: [original.sender],
            });
          }
        } else {
          await sock.sendMessage(targetJid, {
            text: alertHeader,
            mentions: [original.sender],
          });
        }
      } catch (err) {
        console.error('[Anti-Delete Recovery Error]:', err.message);
      }
    }
  });

  // ==========================================================================
  // EVENT HOOK: Incoming Messages, "Forwarded Many Times" Auto-Modifier,
  // Status Reactor, Anti-Link, AFK & Filters
  // ==========================================================================
  sock.ev.on('messages.upsert', async (chatUpdate) => {
    try {
      if (chatUpdate.type !== 'notify') return;

      for (const rawMsg of chatUpdate.messages) {
        if (!rawMsg.message) continue;

        // Feature #10: Auto Status View + Emoji Reaction
        if (rawMsg.key.remoteJid === 'status@broadcast') {
          if (config.AUTO_STATUS_READ) {
            await sock.readMessages([rawMsg.key]);
          }
          if (config.AUTO_STATUS_REACT && rawMsg.key.participant) {
            await sock.sendMessage(
              'status@broadcast',
              { react: { text: config.STATUS_EMOJI, key: rawMsg.key } },
              { statusJidList: [rawMsg.key.participant] }
            );
          }
          continue;
        }

        if (config.AUTO_READ) {
          await sock.readMessages([rawMsg.key]);
        }

        // Serialize message and store in rolling cache for Anti-Delete
        const m = serialize(sock, rawMsg);
        cacheMessage(m);

        // ====================================================================
        // FEATURE #21: Make Every Normal Message You Type Appear as
        // "Forwarded Many Times" (forwardingScore: 999)
        // ====================================================================
        const isPlainUserMessage =
          m.fromMe &&
          db.autoforward?.enabled &&
          db.autoforward?.mode === 'all' &&
          !botSentIds.has(m.id) &&
          !m.isForwarded &&
          m.body &&
          !m.body.startsWith(config.PREFIX) &&
          (m.type === 'conversation' || m.type === 'extendedTextMessage');

        if (isPlainUserMessage) {
          try {
            // Delete the plain outgoing message and immediately replace it with a
            // "Forwarded many times" version (preserving quotes and mentions)
            await m.delete();
            const sendOptions = m.quoted
              ? {
                  quoted: {
                    key: m.quoted.key,
                    message: m.quoted.message,
                  },
                }
              : {};

            const replacement = await sock.sendMessage(
              m.from,
              {
                text: m.body,
                mentions: m.mentionedJid,
                contextInfo: {
                  isForwarded: true,
                  forwardingScore: db.autoforward.score || 999,
                  mentionedJid: m.mentionedJid,
                },
              },
              sendOptions
            );
            if (replacement?.key?.id) {
              markBotSent(replacement.key.id);
            }
            continue;
          } catch (err) {
            console.error('[Auto-Forward Transform Error]:', err.message);
          }
        }

        // Feature #20: Track Group Activity Leaderboard
        if (m.isGroup && m.sender) {
          if (!db.activity[m.from]) db.activity[m.from] = {};
          db.activity[m.from][m.sender] = (db.activity[m.from][m.sender] || 0) + 1;
        }

        // Feature #4: Group Anti-Link Shield
        if (m.isGroup && db.antilink[m.from]?.enabled && !m.isOwner && !m.fromMe) {
          const linkRegex = /chat\.whatsapp\.com\/[A-Za-z0-9]{20,}/i;
          if (linkRegex.test(m.body)) {
            await m.delete();
            const action = db.antilink[m.from].action;
            if (action === 'kick') {
              await sock.groupParticipantsUpdate(m.from, [m.sender], 'remove');
              await m.reply(`🚫 @${m.senderNumber} was removed for posting an unauthorized group link!`, {
                mentions: [m.sender],
              });
            } else {
              if (!db.warnings[m.from]) db.warnings[m.from] = {};
              const strikes = (db.warnings[m.from][m.sender] || 0) + 1;
              db.warnings[m.from][m.sender] = strikes;
              saveDb();

              if (strikes >= 3) {
                db.warnings[m.from][m.sender] = 0;
                await sock.groupParticipantsUpdate(m.from, [m.sender], 'remove');
                await m.reply(`🚫 @${m.senderNumber} reached 3/3 link warnings and was removed!`, {
                  mentions: [m.sender],
                });
              } else {
                await m.reply(
                  `⚠️ *Anti-Link Warning (${strikes}/3)* for @${m.senderNumber}!\nGroup links are prohibited here.`,
                  { mentions: [m.sender] }
                );
              }
            }
            continue;
          }
        }

        // Feature #12: Anti-Spam Velocity Flood Limiter
        if (m.isGroup && db.antispam[m.from] && !m.isOwner && !m.fromMe) {
          if (checkSpam(m.from, m.sender)) {
            await m.reply(`⚡ *Slow down @${m.senderNumber}!* Please avoid flooding the chat.`, {
              mentions: [m.sender],
            });
            continue;
          }
        }

        // Feature #3: Smart AFK System
        if (db.afk[m.sender] && !m.body.startsWith(`${config.PREFIX}afk`)) {
          const elapsed = runtime((Date.now() - db.afk[m.sender].time) / 1000);
          delete db.afk[m.sender];
          saveDb();
          await m.reply(`☀️ *Welcome back @${m.senderNumber}!* Your AFK status has been removed (Away for ${elapsed}).`, {
            mentions: [m.sender],
          });
        }

        const taggedTargets = [...(m.mentionedJid || []), m.quoted?.sender].filter(Boolean);
        for (const jid of new Set(taggedTargets)) {
          if (db.afk[jid] && jid !== m.sender) {
            const info = db.afk[jid];
            const elapsed = runtime((Date.now() - info.time) / 1000);
            await m.reply(
              `🌙 *@${jid.split('@')[0]} is currently AFK*\n• *Reason:* ${info.reason}\n• *Away for:* ${elapsed}`,
              { mentions: [jid] }
            );
          }
        }

        // Feature #17: Custom Keyword Auto-Responder Filters
        if (m.body && !m.body.startsWith(config.PREFIX) && !m.fromMe && db.filters[m.from]) {
          const lower = m.body.trim().toLowerCase();
          if (db.filters[m.from][lower]) {
            await m.reply(db.filters[m.from][lower]);
          }
        }

        // Dispatch prefixed commands to plugins
        await handleCommand(sock, m);
      }
    } catch (err) {
      console.error(chalk.red('[Message Upsert Error]:'), err);
    }
  });

  return sock;
}

startBot().catch((err) => console.error(chalk.red('Fatal initialization error:'), err));
