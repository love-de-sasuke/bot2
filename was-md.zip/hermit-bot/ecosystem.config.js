module.exports = {
  apps: [
    {
      name: 'hermit-bot',
      script: './index.js',
      watch: false,
      max_memory_restart: '500M',
      env: {
        NODE_ENV: 'production',
      },
      exp_backoff_restart_delay: 2000,
    },
  ],
};
