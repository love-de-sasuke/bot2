const axios = require('axios');
const { command } = require('../lib/plugins');
const { getBuffer } = require('../lib/functions');
const { db, saveDb } = require('../lib/store');

// ============================================================================
// FEATURE #19: Disposable TempMail Inbox Inside WhatsApp (.tempmail / .checkmail)
// ============================================================================
command(
  {
    pattern: 'tempmail',
    alias: ['tmail', 'disposable'],
    desc: 'Generate a working disposable email address to receive OTPs and links in chat',
    type: 'tools',
  },
  async (m) => {
    try {
      const login = 'hermit_' + Math.random().toString(36).substring(2, 9);
      const domain = '1secmail.com';
      const email = `${login}@${domain}`;

      db.tempmail[m.sender] = { email, login, domain };
      saveDb();

      await m.reply(
        `📬 *DISPOSABLE TEMP-MAIL GENERATED*\n\n` +
          `📧 *Address:* \`${email}\`\n\n` +
          `_Use this address to sign up or receive verification codes, then type_ \`.checkmail\` _to read incoming emails directly in WhatsApp!_`
      );
    } catch (err) {
      await m.reply('❌ Failed to generate temporary email.');
    }
  }
);

command(
  {
    pattern: 'checkmail',
    alias: ['inbox'],
    desc: 'Check incoming messages and OTP codes in your generated TempMail inbox',
    type: 'tools',
  },
  async (m) => {
    const mail = db.tempmail[m.sender];
    if (!mail) {
      return await m.reply('⚠️ You do not have an active TempMail yet! Generate one first with `.tempmail`.');
    }

    await m.react('📨');
    try {
      const listUrl = `https://www.1secmail.com/api/v1/?action=getMessages&login=${mail.login}&domain=${mail.domain}`;
      const { data: messages } = await axios.get(listUrl);

      if (!messages || messages.length === 0) {
        return await m.reply(`📭 *Inbox Empty* (\`${mail.email}\`)\nNo emails received yet. Try again in a few seconds!`);
      }

      const latest = messages[0];
      const readUrl = `https://www.1secmail.com/api/v1/?action=readMessage&login=${mail.login}&domain=${mail.domain}&id=${latest.id}`;
      const { data: fullMsg } = await axios.get(readUrl);

      const text =
        `📩 *LATEST EMAIL RECEIVED* (\`${mail.email}\`)\n\n` +
        `• *From:* ${fullMsg.from}\n` +
        `• *Subject:* ${fullMsg.subject}\n` +
        `• *Date:* ${fullMsg.date}\n\n` +
        `📝 *Message Body:*\n${(fullMsg.textBody || 'No plain text content').slice(0, 1200)}`;

      await m.reply(text);
    } catch (err) {
      await m.reply('❌ Unable to fetch inbox right now.');
    }
  }
);

command(
  {
    pattern: 'calc',
    alias: ['math', 'calculate'],
    desc: 'Calculate mathematical expressions',
    type: 'tools',
  },
  async (m, match) => {
    if (!match) return await m.reply('Provide expression to calculate: `.calc 15 * 84 + 120`');

    try {
      const cleanExpr = match.replace(/[^0-9+\-*/().%^ ]/g, '');
      const result = Function(`'use strict'; return (${cleanExpr})`)();
      await m.reply(`🧮 *Result:*\n\`${cleanExpr}\` = *${result}*`);
    } catch (err) {
      await m.reply('❌ Invalid math expression.');
    }
  }
);

command(
  {
    pattern: 'qr',
    alias: ['qrcode'],
    desc: 'Generate a QR code image from text or URL',
    type: 'tools',
  },
  async (m, match, { sock }) => {
    if (!match) return await m.reply('Please provide text or link: `.qr https://google.com`');

    try {
      const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=500x500&data=${encodeURIComponent(match)}`;
      const buffer = await getBuffer(qrUrl);
      await sock.sendMessage(m.from, { image: buffer, caption: `Here is your QR Code for:\n${match}` }, { quoted: m });
    } catch (err) {
      await m.reply('❌ Failed to generate QR code.');
    }
  }
);

command(
  {
    pattern: 'shorturl',
    alias: ['short', 'tinyurl'],
    desc: 'Shorten a long URL',
    type: 'tools',
  },
  async (m, match) => {
    if (!match) return await m.reply('Provide a URL: `.shorturl https://example.com/very/long/url`');

    try {
      const res = await axios.get(`https://tinyurl.com/api-create.php?url=${encodeURIComponent(match)}`);
      await m.reply(`🔗 *Shortened URL:*\n${res.data}`);
    } catch (err) {
      await m.reply('❌ Failed to shorten URL.');
    }
  }
);
