const { command } = require('../lib/plugins');
const { db, saveDb } = require('../lib/store');

// ============================================================================
// FEATURE #4: Anti-Link & Auto-Strike Group Shield (.antilink)
// ============================================================================
command(
  {
    pattern: 'antilink',
    desc: 'Protect group from unauthorized WhatsApp links (on / off / warn / kick)',
    type: 'group',
    onlyGroup: true,
    onlyAdmin: true,
    onlyBotAdmin: true,
  },
  async (m, match) => {
    const arg = match.trim().toLowerCase();
    if (!db.antilink[m.from]) db.antilink[m.from] = { enabled: false, action: 'warn' };

    if (arg === 'on') {
      db.antilink[m.from].enabled = true;
      saveDb();
      return await m.reply(`🛡️ *Anti-Link Shield Enabled* (Action: *${db.antilink[m.from].action.toUpperCase()}*)`);
    }
    if (arg === 'off') {
      db.antilink[m.from].enabled = false;
      saveDb();
      return await m.reply('⚪ *Anti-Link Shield Disabled.*');
    }
    if (arg === 'warn' || arg === 'kick') {
      db.antilink[m.from].enabled = true;
      db.antilink[m.from].action = arg;
      saveDb();
      return await m.reply(`🛡️ *Anti-Link mode set to:* \`${arg.toUpperCase()}\``);
    }

    await m.reply(
      `🛡️ *Group Anti-Link Status:* ${db.antilink[m.from].enabled ? 'ON ✅' : 'OFF ❌'}\n` +
        `⚡ *Penalty Mode:* ${db.antilink[m.from].action.toUpperCase()}\n\n` +
        `Usage: \`.antilink on | off | warn | kick\``
    );
  }
);

// ============================================================================
// FEATURE #9: Native Interactive Poll Builder (.poll)
// ============================================================================
command(
  {
    pattern: 'poll',
    desc: 'Create an interactive WhatsApp Poll (.poll Question | Opt1 | Opt2 | Opt3)',
    type: 'group',
  },
  async (m, match, { sock }) => {
    const parts = match.split('|').map((s) => s.trim()).filter(Boolean);
    if (parts.length < 3) {
      return await m.reply('📊 *Usage:* `.poll Best Language? | JavaScript | Python | Rust`');
    }

    const [question, ...options] = parts;
    await sock.sendMessage(m.from, {
      poll: {
        name: question,
        values: options.slice(0, 12),
        selectableCount: 1,
      },
    });
  }
);

// ============================================================================
// FEATURE #12: Anti-Spam Velocity Flood Limiter (.antispam)
// ============================================================================
command(
  {
    pattern: 'antispam',
    desc: 'Toggle sliding-window anti-flood protection (>6 msgs in 4s)',
    type: 'group',
    onlyGroup: true,
    onlyAdmin: true,
  },
  async (m, match) => {
    const arg = match.trim().toLowerCase();
    if (arg === 'on' || arg === 'off') {
      db.antispam[m.from] = arg === 'on';
      saveDb();
      return await m.reply(`⚡ *Anti-Spam Flood Protection:* ${arg.toUpperCase()}`);
    }
    await m.reply(`Usage: \`.antispam on\` or \`.antispam off\``);
  }
);

// ============================================================================
// FEATURE #14: VCard Generator (.vcard) & Bulk Group VCF Exporter (.exportvcf)
// ============================================================================
command(
  {
    pattern: 'vcard',
    desc: 'Generate a savable WhatsApp Contact Card for any user',
    type: 'group',
  },
  async (m, match, { sock }) => {
    const target = m.quoted ? m.quoted.sender : m.mentionedJid?.[0] || m.sender;
    const num = target.split('@')[0];
    const name = match.replace(/@\d+/g, '').trim() || `User +${num}`;

    const vcard =
      'BEGIN:VCARD\n' +
      'VERSION:3.0\n' +
      `FN:${name}\n` +
      `TEL;type=CELL;type=VOICE;waid=${num}:+${num}\n` +
      'END:VCARD';

    await sock.sendMessage(
      m.from,
      {
        contacts: {
          displayName: name,
          contacts: [{ vcard }],
        },
      },
      { quoted: m }
    );
  }
);

command(
  {
    pattern: 'exportvcf',
    alias: ['vcf'],
    desc: 'Export all group participants into a single downloadable .vcf contact file',
    type: 'group',
    onlyGroup: true,
    onlyAdmin: true,
  },
  async (m, _, { sock, groupMetadata, participants }) => {
    let vcfContent = '';
    participants.forEach((p, idx) => {
      const num = p.id.split('@')[0];
      vcfContent +=
        'BEGIN:VCARD\n' +
        'VERSION:3.0\n' +
        `FN:${groupMetadata.subject} Member #${idx + 1} (+${num})\n` +
        `TEL;type=CELL;type=VOICE;waid=${num}:+${num}\n` +
        'END:VCARD\n';
    });

    const buffer = Buffer.from(vcfContent, 'utf8');
    await sock.sendMessage(
      m.from,
      {
        document: buffer,
        mimetype: 'text/vcard',
        fileName: `${groupMetadata.subject.replace(/[^a-zA-Z0-9]/g, '_')}_Contacts.vcf`,
        caption: `📇 *Exported ${participants.length} Contacts* from *${groupMetadata.subject}*`,
      },
      { quoted: m }
    );
  }
);

// ============================================================================
// FEATURE #18: Welcome & Goodbye Group Greeter (.welcome / .goodbye)
// ============================================================================
command(
  {
    pattern: 'welcome',
    desc: 'Toggle automatic welcome banner with profile picture for new group members',
    type: 'group',
    onlyGroup: true,
    onlyAdmin: true,
  },
  async (m, match) => {
    const state = match.trim().toLowerCase();
    if (state === 'on' || state === 'off') {
      db.welcome[m.from] = state === 'on';
      saveDb();
      return await m.reply(`👋 *Welcome Greeter:* ${state.toUpperCase()}`);
    }
    await m.reply(`Usage: \`.welcome on\` or \`.welcome off\``);
  }
);

command(
  {
    pattern: 'goodbye',
    desc: 'Toggle automatic farewell message when members leave the group',
    type: 'group',
    onlyGroup: true,
    onlyAdmin: true,
  },
  async (m, match) => {
    const state = match.trim().toLowerCase();
    if (state === 'on' || state === 'off') {
      db.goodbye[m.from] = state === 'on';
      saveDb();
      return await m.reply(`👋 *Goodbye Greeter:* ${state.toUpperCase()}`);
    }
    await m.reply(`Usage: \`.goodbye on\` or \`.goodbye off\``);
  }
);

// ============================================================================
// FEATURE #20: Group Activity Leaderboard (.topchat) & Silent Finder (.inactive)
// ============================================================================
command(
  {
    pattern: 'topchat',
    alias: ['leaderboard', 'active'],
    desc: 'View the most active group members ranked by message volume',
    type: 'group',
    onlyGroup: true,
  },
  async (m, _, { groupMetadata }) => {
    const stats = db.activity[m.from] || {};
    const sorted = Object.entries(stats)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 15);

    if (sorted.length === 0) {
      return await m.reply('📊 No activity recorded for this group yet.');
    }

    const medals = ['🥇', '🥈', '🥉'];
    let text = `🏆 *ACTIVITY LEADERBOARD — ${groupMetadata.subject}*\n\n`;
    const mentions = [];

    sorted.forEach(([jid, count], idx) => {
      const badge = medals[idx] || `${idx + 1}.`;
      text += `${badge} @${jid.split('@')[0]} — *${count} msgs*\n`;
      mentions.push(jid);
    });

    await m.reply(text, { mentions });
  }
);

command(
  {
    pattern: 'inactive',
    alias: ['ghosts'],
    desc: 'List silent/ghost group members with 0 recorded messages',
    type: 'group',
    onlyGroup: true,
    onlyAdmin: true,
  },
  async (m, _, { participants }) => {
    const stats = db.activity[m.from] || {};
    const ghosts = participants.filter((p) => !stats[p.id] || stats[p.id] === 0);

    if (ghosts.length === 0) {
      return await m.reply('🎉 Every member in this group has been active!');
    }

    let text = `👻 *SILENT / INACTIVE MEMBERS (${ghosts.length})*\n\n`;
    const mentions = [];
    ghosts.slice(0, 40).forEach((p, i) => {
      text += `${i + 1}. @${p.id.split('@')[0]}\n`;
      mentions.push(p.id);
    });
    if (ghosts.length > 40) text += `\n_...and ${ghosts.length - 40} more._`;

    await m.reply(text, { mentions });
  }
);

// Standard Group Moderation Commands (Tagall, Hidetag, Kick, Promote, Demote, Mute, Unmute, Link)
command(
  {
    pattern: 'tagall',
    alias: ['everyone'],
    desc: 'Mention every participant in the group',
    type: 'group',
    onlyGroup: true,
    onlyAdmin: true,
  },
  async (m, match, { participants }) => {
    const customMsg = match ? `📢 *Message:* ${match}\n\n` : '';
    let text = `👥 *GROUP ANNOUNCEMENT*\n${customMsg}`;
    const mentions = participants.map((p) => p.id);
    participants.forEach((p, idx) => {
      text += `${idx + 1}. @${p.id.split('@')[0]}\n`;
    });
    await m.reply(text, { mentions });
  }
);

command(
  {
    pattern: 'hidetag',
    alias: ['htag'],
    desc: 'Broadcast message tagging all participants invisibly',
    type: 'group',
    onlyGroup: true,
    onlyAdmin: true,
  },
  async (m, match, { sock, participants }) => {
    const text = match || m.quoted?.body || '📢 Attention everyone!';
    await sock.sendMessage(m.from, { text, mentions: participants.map((p) => p.id) });
  }
);

command(
  {
    pattern: 'kick',
    alias: ['remove'],
    desc: 'Remove a participant from the group',
    type: 'group',
    onlyGroup: true,
    onlyAdmin: true,
    onlyBotAdmin: true,
  },
  async (m, match, { sock }) => {
    let target = m.quoted ? m.quoted.sender : m.mentionedJid?.[0];
    if (!target && match) target = match.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
    if (!target) return await m.reply('⚠️ Reply to or mention (@user) the member to remove.');

    await sock.groupParticipantsUpdate(m.from, [target], 'remove');
    await m.reply(`👋 Removed @${target.split('@')[0]}`, { mentions: [target] });
  }
);

command(
  {
    pattern: 'promote',
    desc: 'Promote a member to group admin',
    type: 'group',
    onlyGroup: true,
    onlyAdmin: true,
    onlyBotAdmin: true,
  },
  async (m, match, { sock }) => {
    let target = m.quoted ? m.quoted.sender : m.mentionedJid?.[0];
    if (!target && match) target = match.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
    if (!target) return await m.reply('⚠️ Reply to or mention the user to promote.');

    await sock.groupParticipantsUpdate(m.from, [target], 'promote');
    await m.reply(`🎉 Promoted @${target.split('@')[0]} to Admin!`, { mentions: [target] });
  }
);

command(
  {
    pattern: 'demote',
    desc: 'Demote an admin to regular member',
    type: 'group',
    onlyGroup: true,
    onlyAdmin: true,
    onlyBotAdmin: true,
  },
  async (m, match, { sock }) => {
    let target = m.quoted ? m.quoted.sender : m.mentionedJid?.[0];
    if (!target && match) target = match.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
    if (!target) return await m.reply('⚠️ Reply to or mention the admin to demote.');

    await sock.groupParticipantsUpdate(m.from, [target], 'demote');
    await m.reply(`⬇️ Demoted @${target.split('@')[0]}.`, { mentions: [target] });
  }
);

command(
  {
    pattern: 'mute',
    desc: 'Close group chat (admins only)',
    type: 'group',
    onlyGroup: true,
    onlyAdmin: true,
    onlyBotAdmin: true,
  },
  async (m, _, { sock }) => {
    await sock.groupSettingUpdate(m.from, 'announcement');
    await m.reply('🔒 Group muted (admins only).');
  }
);

command(
  {
    pattern: 'unmute',
    desc: 'Open group chat (all members)',
    type: 'group',
    onlyGroup: true,
    onlyAdmin: true,
    onlyBotAdmin: true,
  },
  async (m, _, { sock }) => {
    await sock.groupSettingUpdate(m.from, 'not_announcement');
    await m.reply('🔓 Group unmuted (all participants can send messages).');
  }
);

command(
  {
    pattern: 'link',
    alias: ['grouplink'],
    desc: 'Get group invite link',
    type: 'group',
    onlyGroup: true,
    onlyBotAdmin: true,
  },
  async (m, _, { sock }) => {
    const code = await sock.groupInviteCode(m.from);
    await m.reply(`🔗 *Group Link:*\nhttps://chat.whatsapp.com/${code}`);
  }
);
