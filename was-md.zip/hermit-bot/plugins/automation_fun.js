const { command } = require('../lib/plugins');
const { db, saveDb, games } = require('../lib/store');
const { sleep, runtime } = require('../lib/functions');

// ============================================================================
// FEATURE #3: Smart AFK (Away From Keyboard) Auto-Responder (.afk)
// ============================================================================
command(
  {
    pattern: 'afk',
    desc: 'Set yourself as AFK; bot auto-replies when someone tags or replies to you',
    type: 'automation',
  },
  async (m, match) => {
    const reason = match.trim() || 'Busy right now, will reply soon!';
    db.afk[m.sender] = {
      reason,
      time: Date.now(),
    };
    saveDb();
    await m.reply(`🌙 *@${m.senderNumber} is now AFK*\n📝 *Reason:* ${reason}`, {
      mentions: [m.sender],
    });
  }
);

// ============================================================================
// FEATURE #7: Self-Destructing Vanish Messages (.vanish) & Scheduled Delivery (.schedule)
// ============================================================================
command(
  {
    pattern: 'vanish',
    alias: ['selfdestruct', 'bomb'],
    desc: 'Send a message with a live countdown that self-destructs (.vanish 5 Secret Code)',
    type: 'automation',
  },
  async (m, match) => {
    const args = match.trim().split(/ +/);
    const seconds = Math.min(Math.max(parseInt(args.shift(), 10) || 5, 3), 30);
    const secretText = args.join(' ');

    if (!secretText) {
      return await m.reply('💣 *Usage:* `.vanish <seconds> <secret message>` (e.g. `.vanish 5 Passcode is 4829`)');
    }

    const sent = await m.reply(`💣 *SELF-DESTRUCTING MESSAGE (${seconds}s)*\n\n${secretText}`);
    for (let left = seconds - 1; left >= 1; left--) {
      await sleep(1000);
      if (left <= 3 || left % 2 === 0) {
        await m.edit(`💣 *SELF-DESTRUCTING MESSAGE (${left}s)*\n\n${secretText}`, sent.key);
      }
    }
    await sleep(1000);
    await m.delete(sent.key);
  }
);

command(
  {
    pattern: 'schedule',
    alias: ['delay'],
    desc: 'Schedule a message to be sent after a delay (.schedule 10s Hello!)',
    type: 'automation',
  },
  async (m, match, { sock }) => {
    const args = match.trim().split(/ +/);
    const timeStr = args.shift() || '';
    const msgText = args.join(' ');

    const matchTime = timeStr.match(/^(\d+)(s|m|h)$/i);
    if (!matchTime || !msgText) {
      return await m.reply('⏰ *Usage:* `.schedule <10s | 5m | 1h> <message>`');
    }

    const amount = parseInt(matchTime[1], 10);
    const unit = matchTime[2].toLowerCase();
    const ms = unit === 'h' ? amount * 3600000 : unit === 'm' ? amount * 60000 : amount * 1000;

    await m.reply(`⏳ Scheduled message to be delivered in *${timeStr}*.`);
    setTimeout(async () => {
      await sock.sendMessage(m.from, {
        text: `⏰ *Scheduled Message from @${m.senderNumber}:*\n\n${msgText}`,
        mentions: [m.sender],
      });
    }, ms);
  }
);

// ============================================================================
// FEATURE #8: Live In-Place Message Edit Animations (.type & .hack)
// ============================================================================
command(
  {
    pattern: 'type',
    alias: ['typewriter'],
    desc: 'Animate text character-by-character using real-time message editing',
    type: 'automation',
  },
  async (m, match) => {
    if (!match) return await m.reply('⌨️ Provide text to animate: `.type Hello Hermit World!`');
    const words = match.split(' ');
    const sent = await m.reply('⌨️ `...`');
    let current = '';

    for (let i = 0; i < words.length; i++) {
      current += (i === 0 ? '' : ' ') + words[i];
      await sleep(450);
      await m.edit(`${current} ▌`, sent.key);
    }
    await sleep(300);
    await m.edit(current, sent.key);
  }
);

command(
  {
    pattern: 'hack',
    desc: 'Run a fun live-edited terminal simulation in a single chat bubble',
    type: 'automation',
  },
  async (m, match) => {
    const target = match || `@${m.senderNumber}`;
    const stages = [
      `💻 \`[05%]\` Initializing Hermit SSH probe on ${target}...`,
      `🔍 \`[25%]\` Bypassing WhatsApp E2E stanza firewall...`,
      `📡 \`[55%]\` Extracting session keys & sticker vault...`,
      `🔓 \`[85%]\` Decrypting recent midnight voice notes...`,
      `✅ \`[100%]\` Simulation complete on ${target}! (Just kidding 😄)`,
    ];

    const sent = await m.reply(stages[0]);
    for (let i = 1; i < stages.length; i++) {
      await sleep(900);
      await m.edit(stages[i], sent.key);
    }
  }
);

// ============================================================================
// FEATURE #13: Chat Wordle (.wordle / .guess) & Tic-Tac-Toe (.ttt)
// ============================================================================
const WORD_LIST = ['CRANE', 'SLATE', 'AUDIO', 'FLAME', 'BRAIN', 'PIXEL', 'GHOST', 'STORM', 'LIGHT', 'MAGIC', 'SMART', 'CLOUD'];

command(
  {
    pattern: 'wordle',
    desc: 'Start or view a 5-letter Wordle puzzle in the current chat',
    type: 'automation',
  },
  async (m) => {
    const secret = WORD_LIST[Math.floor(Math.random() * WORD_LIST.length)];
    games.set(`wordle_${m.from}`, { word: secret, attempts: [], max: 6 });

    await m.reply(
      `🟩🟨⬛ *WHATSAPP WORDLE STARTED!*\n\n` +
        `Guess the hidden 5-letter word in 6 tries.\n` +
        `Type \`.guess <5-letter-word>\` (e.g. \`.guess CRANE\`) to play!`
    );
  }
);

command(
  {
    pattern: 'guess',
    desc: 'Submit a 5-letter word guess for the active Wordle game',
    type: 'automation',
  },
  async (m, match) => {
    const game = games.get(`wordle_${m.from}`);
    if (!game) return await m.reply('⚠️ No active Wordle game! Start one with `.wordle`.');

    const guess = match.trim().toUpperCase();
    if (guess.length !== 5 || !/^[A-Z]{5}$/.test(guess)) {
      return await m.reply('⚠️ Please enter a valid 5-letter English word (e.g. `.guess SLATE`).');
    }

    const secret = game.word;
    let row = '';
    for (let i = 0; i < 5; i++) {
      if (guess[i] === secret[i]) row += '🟩';
      else if (secret.includes(guess[i])) row += '🟨';
      else row += '⬛';
    }

    game.attempts.push(`${row}  *${guess.split('').join(' ')}*`);
    const board = game.attempts.join('\n');

    if (guess === secret) {
      games.delete(`wordle_${m.from}`);
      return await m.reply(`🎉 *BINGO! You solved it in ${game.attempts.length}/${game.max}!*\n\n${board}`);
    }

    if (game.attempts.length >= game.max) {
      games.delete(`wordle_${m.from}`);
      return await m.reply(`💀 *Game Over!* The word was *${secret}*.\n\n${board}`);
    }

    await m.reply(`🧩 *Wordle (${game.attempts.length}/${game.max})*\n\n${board}`);
  }
);

// ============================================================================
// FEATURE #15: Personal Todo Pinboard (.todo) & Live Timer Reminder (.remind)
// ============================================================================
command(
  {
    pattern: 'todo',
    desc: 'Manage your personal persistent task list (.todo add/list/done/clear)',
    type: 'automation',
  },
  async (m, match) => {
    if (!db.todos[m.sender]) db.todos[m.sender] = [];
    const list = db.todos[m.sender];

    const [sub, ...rest] = match.trim().split(/ +/);
    const action = (sub || 'list').toLowerCase();
    const arg = rest.join(' ');

    if (action === 'add' && arg) {
      list.push({ text: arg, done: false, createdAt: Date.now() });
      saveDb();
      return await m.reply(`📌 Added task #${list.length}: *${arg}*`);
    }
    if (action === 'done') {
      const idx = parseInt(arg, 10) - 1;
      if (!list[idx]) return await m.reply('⚠️ Invalid task number.');
      list[idx].done = true;
      saveDb();
      return await m.reply(`✅ Marked task #${idx + 1} as completed!`);
    }
    if (action === 'clear') {
      db.todos[m.sender] = [];
      saveDb();
      return await m.reply('🗑️ Cleared all tasks from your Todo board.');
    }

    if (list.length === 0) {
      return await m.reply('📋 Your Todo list is empty! Add one with `.todo add Buy coffee`');
    }

    let out = `📋 *YOUR TODO PINBOARD*\n\n`;
    list.forEach((item, i) => {
      out += `${i + 1}. ${item.done ? '✅ ~' + item.text + '~' : '⬜ ' + item.text}\n`;
    });
    out += `\n_Use .todo done <num> or .todo clear_`;
    await m.reply(out);
  }
);

command(
  {
    pattern: 'remind',
    alias: ['timer'],
    desc: 'Set a live countdown reminder that tags you (.remind 15m Join standup)',
    type: 'automation',
  },
  async (m, match) => {
    const [timeStr, ...rest] = match.trim().split(/ +/);
    const note = rest.join(' ');
    const parsed = (timeStr || '').match(/^(\d+)(s|m|h)$/i);

    if (!parsed || !note) {
      return await m.reply('⏰ *Usage:* `.remind <10s | 15m | 2h> <reminder text>`');
    }

    const val = parseInt(parsed[1], 10);
    const unit = parsed[2].toLowerCase();
    const delayMs = unit === 'h' ? val * 3600000 : unit === 'm' ? val * 60000 : val * 1000;

    await m.reply(`🔔 Reminder set for *${timeStr}*: "${note}"`);
    setTimeout(async () => {
      await m.reply(`🔔 *REMINDER ALERT for @${m.senderNumber}!*\n\n📌 *Task:* ${note}`, {
        mentions: [m.sender],
      });
    }, delayMs);
  }
);

// ============================================================================
// FEATURE #17: Custom Keyword Auto-Responder Filters (.filter)
// ============================================================================
command(
  {
    pattern: 'filter',
    desc: 'Set custom auto-reply keyword triggers (.filter add hello | Hi there!)',
    type: 'automation',
  },
  async (m, match) => {
    if (!db.filters[m.from]) db.filters[m.from] = {};
    const chatFilters = db.filters[m.from];

    const [sub, ...rest] = match.trim().split(/ +/);
    const action = (sub || 'list').toLowerCase();
    const payload = rest.join(' ');

    if (action === 'add' && payload.includes('|')) {
      const [trigger, ...replyParts] = payload.split('|');
      const key = trigger.trim().toLowerCase();
      const response = replyParts.join('|').trim();
      chatFilters[key] = response;
      saveDb();
      return await m.reply(`🤖 Added auto-filter for *"${key}"* → "${response}"`);
    }

    if (action === 'del' && payload) {
      const key = payload.trim().toLowerCase();
      delete chatFilters[key];
      saveDb();
      return await m.reply(`🗑️ Removed filter *"${key}"*`);
    }

    const keys = Object.keys(chatFilters);
    if (keys.length === 0) {
      return await m.reply('🤖 No active keyword filters in this chat.\nAdd one: `.filter add price | Our pricing starts at $10`');
    }

    let text = `🤖 *ACTIVE AUTO-FILTERS*\n\n`;
    for (const [k, v] of Object.entries(chatFilters)) {
      text += `• *"${k}"* → ${v}\n`;
    }
    await m.reply(text);
  }
);
