const fs = require('fs');
const path = require('path');
const axios = require('axios');
const ffmpeg = require('fluent-ffmpeg');
const config = require('../config');
const { command } = require('../lib/plugins');
const { getRandom } = require('../lib/functions');
const { addExifToWebp } = require('../lib/exif');

/**
 * Convert image/video buffer to WebP sticker with EXIF Pack & Author metadata
 */
function mediaToWebp(mediaBuffer, isVideo = false, pack = config.STICKER_PACK, author = config.STICKER_AUTHOR) {
  return new Promise((resolve, reject) => {
    const tmpInput = path.join(__dirname, '..', getRandom(isVideo ? 'mp4' : 'jpg'));
    const tmpOutput = path.join(__dirname, '..', getRandom('webp'));

    fs.writeFileSync(tmpInput, mediaBuffer);

    let ff = ffmpeg(tmpInput).outputOptions([
      '-vcodec', 'libwebp',
      '-vf',
      "scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse",
    ]);

    if (isVideo) {
      ff = ff.outputOptions(['-loop', '0', '-ss', '00:00:00', '-t', '00:00:06', '-preset', 'default', '-an', '-vsync', '0']);
    }

    ff.toFormat('webp')
      .save(tmpOutput)
      .on('end', () => {
        try {
          const rawWebp = fs.readFileSync(tmpOutput);
          if (fs.existsSync(tmpInput)) fs.unlinkSync(tmpInput);
          if (fs.existsSync(tmpOutput)) fs.unlinkSync(tmpOutput);
          resolve(addExifToWebp(rawWebp, pack, author));
        } catch (e) {
          reject(e);
        }
      })
      .on('error', (err) => {
        if (fs.existsSync(tmpInput)) fs.unlinkSync(tmpInput);
        if (fs.existsSync(tmpOutput)) fs.unlinkSync(tmpOutput);
        reject(err);
      });
  });
}

/**
 * Apply an FFmpeg audio filter graph to an audio buffer
 */
function applyAudioFilter(audioBuffer, filterStr) {
  return new Promise((resolve, reject) => {
    const tmpIn = path.join(__dirname, '..', getRandom('ogg'));
    const tmpOut = path.join(__dirname, '..', getRandom('mp3'));
    fs.writeFileSync(tmpIn, audioBuffer);

    ffmpeg(tmpIn)
      .audioFilter(filterStr)
      .toFormat('mp3')
      .save(tmpOut)
      .on('end', () => {
        const out = fs.readFileSync(tmpOut);
        if (fs.existsSync(tmpIn)) fs.unlinkSync(tmpIn);
        if (fs.existsSync(tmpOut)) fs.unlinkSync(tmpOut);
        resolve(out);
      })
      .on('error', (err) => {
        if (fs.existsSync(tmpIn)) fs.unlinkSync(tmpIn);
        if (fs.existsSync(tmpOut)) fs.unlinkSync(tmpOut);
        reject(err);
      });
  });
}

// ============================================================================
// FEATURE #5: Audio Effects & Voice Changer Studio
// (.bass, .nightcore, .slow, .robot, .deep, .reverse)
// ============================================================================
const audioEffects = {
  bass: { filter: 'equalizer=f=54:width_type=o:width=2:g=20', desc: 'Boost heavy sub-bass on replied audio' },
  nightcore: { filter: 'asetrate=44100*1.25,aresample=44100,atempo=1.05', desc: 'High-pitch anime Nightcore remix' },
  slow: { filter: 'asetrate=44100*0.8,aresample=44100', desc: 'Slowed + reverb vaporwave audio effect' },
  deep: { filter: 'asetrate=44100*0.65,aresample=44100,atempo=1.3', desc: 'Deep anonymous voice pitch shifter' },
  robot: { filter: "afftfilt=real='hypot(re,im)*sin(0)':imag='hypot(re,im)*cos(0)':win_size=512:overlap=0.75", desc: 'Robotic vocoder voice filter' },
  reverse: { filter: 'areverse', desc: 'Reverse audio playback backwards' },
};

for (const [effectName, meta] of Object.entries(audioEffects)) {
  command(
    {
      pattern: effectName,
      desc: meta.desc,
      type: 'media',
    },
    async (m, _, { sock }) => {
      if (!m.quoted || m.quoted.type !== 'audioMessage') {
        return await m.reply(`🎙️ Reply to a voice note or audio file with \`.${effectName}\``);
      }

      await m.react('🎧');
      try {
        const rawAudio = await m.quoted.download();
        const processed = await applyAudioFilter(rawAudio, meta.filter);
        await sock.sendMessage(
          m.from,
          { audio: processed, mimetype: 'audio/mp4', ptt: true },
          { quoted: m }
        );
      } catch (err) {
        await m.reply(`❌ Audio filter failed: ${err.message}`);
      }
    }
  );
}

// ============================================================================
// FEATURE #6: Quote-Chat Bubble Sticker Maker (.qc)
// ============================================================================
command(
  {
    pattern: 'qc',
    alias: ['quotely'],
    desc: 'Generate a realistic chat bubble sticker from text or replied message',
    type: 'media',
  },
  async (m, match, { sock }) => {
    const text = match || m.quoted?.body;
    if (!text) return await m.reply('💬 Provide text or reply to a message: `.qc Hello world!`');

    const targetJid = m.quoted ? m.quoted.sender : m.sender;
    const targetName = m.quoted ? `+${m.quoted.senderNumber}` : m.pushName;
    let avatar = 'https://i.ibb.co/3Fh9V6p/avatar-default.png';

    try {
      avatar = await sock.profilePictureUrl(targetJid, 'image');
    } catch (e) {
      // Fallback default avatar
    }

    await m.react('🎨');
    try {
      const payload = {
        type: 'quote',
        format: 'png',
        backgroundColor: '#1b1429',
        width: 512,
        height: 768,
        scale: 2,
        messages: [
          {
            entities: [],
            avatar: true,
            from: { id: 1, name: targetName, photo: { url: avatar } },
            text,
            replyMessage: {},
          },
        ],
      };

      const res = await axios.post('https://bot.lyo.su/quote/generate', payload, {
        headers: { 'Content-Type': 'application/json' },
      });
      const imgBuffer = Buffer.from(res.data.result.image, 'base64');
      const stickerBuffer = await mediaToWebp(imgBuffer, false);
      await sock.sendMessage(m.from, { sticker: stickerBuffer }, { quoted: m });
    } catch (err) {
      await m.reply('❌ Failed to render quote bubble sticker.');
    }
  }
);

// ============================================================================
// FEATURE #11: Sticker Stealer & Custom EXIF Pack/Author Rewriter (.take)
// ============================================================================
command(
  {
    pattern: 'take',
    alias: ['steal', 'wm'],
    desc: 'Change a sticker’s Pack Name and Author metadata (.take MyPack | MyName)',
    type: 'media',
  },
  async (m, match, { sock }) => {
    if (!m.quoted || m.quoted.type !== 'stickerMessage') {
      return await m.reply('🏷️ Reply to any sticker with `.take PackName | AuthorName`');
    }

    const [pack, author] = match.split('|').map((s) => s.trim());
    const finalPack = pack || m.pushName || config.STICKER_PACK;
    const finalAuthor = author || config.BOT_NAME;

    await m.react('🪄');
    try {
      const rawWebp = await m.quoted.download();
      const rebranded = addExifToWebp(rawWebp, finalPack, finalAuthor);
      await sock.sendMessage(m.from, { sticker: rebranded }, { quoted: m });
    } catch (err) {
      await m.reply(`❌ Failed to rewrite sticker EXIF: ${err.message}`);
    }
  }
);

// Standard Sticker & ToImg commands
command(
  {
    pattern: 'sticker',
    alias: ['s', 'stk'],
    desc: 'Convert an image or short video into a WebP sticker',
    type: 'media',
  },
  async (m, _, { sock }) => {
    const target = m.quoted ? m.quoted : m;
    if (!target || !target.isMedia) {
      return await m.reply('📸 Reply to an image or short video with `.sticker`');
    }

    await m.react('⏳');
    try {
      const buffer = await target.download();
      const stickerBuffer = await mediaToWebp(buffer, target.type === 'videoMessage');
      await sock.sendMessage(m.from, { sticker: stickerBuffer }, { quoted: m });
      await m.react('✅');
    } catch (err) {
      await m.reply('❌ Failed to convert media to sticker.');
    }
  }
);
