const os = require('os');
const config = require('../config');
const { command, commands } = require('../lib/plugins');
const { runtime, formatBytes } = require('../lib/functions');

const startTime = Date.now();

command(
  {
    pattern: 'ping',
    alias: ['speed'],
    desc: 'Measure bot response latency',
    type: 'general',
  },
  async (m) => {
    const start = Date.now();
    await m.react('⚡');
    const latency = Date.now() - start;
    await m.reply(`*Pong!* 🚀\n*Speed:* \`${latency} ms\``);
  }
);

command(
  {
    pattern: 'alive',
    alias: ['info', 'bot'],
    desc: 'Check if the bot is active and see system status',
    type: 'general',
  },
  async (m, _, { sock }) => {
    const uptimeStr = runtime((Date.now() - startTime) / 1000);
    const usedMem = formatBytes(process.memoryUsage().rss);
    const totalMem = formatBytes(os.totalmem());

    const aliveText =
`╭─── *${config.BOT_NAME}* ───╮
│ *Owner:* ${config.OWNER_NAME}
│ *Mode:* ${config.MODE}
│ *Prefix:* \`${config.PREFIX}\`
│ *Uptime:* ${uptimeStr}
│ *RAM:* ${usedMem} / ${totalMem}
│ *Node:* ${process.version}
│ *Platform:* ${os.platform()} (${os.arch()})
╰──────────────────────╯

_Hermit WhatsApp bot engine running smoothly._`;

    await m.reply(aliveText);
  }
);

command(
  {
    pattern: 'uptime',
    desc: 'Check bot uptime duration',
    type: 'general',
  },
  async (m) => {
    const uptimeStr = runtime((Date.now() - startTime) / 1000);
    await m.reply(`⏱️ *Current Uptime:* ${uptimeStr}`);
  }
);

command(
  {
    pattern: 'menu',
    alias: ['help', 'list'],
    desc: 'Display all available commands categorized',
    type: 'general',
  },
  async (m, match, { commands }) => {
    const categories = {};

    // Group commands by category
    for (const cmd of commands) {
      const type = cmd.type ? cmd.type.toLowerCase() : 'other';
      if (!categories[type]) categories[type] = [];
      categories[type].push(cmd);
    }

    let menuText = `╭───「 *${config.BOT_NAME.toUpperCase()}* 」───\n`;
    menuText += `│ 👤 *Owner:* ${config.OWNER_NAME}\n`;
    menuText += `│ ⚙️ *Prefix:* \`${config.PREFIX}\`\n`;
    menuText += `│ 🌐 *Mode:* ${config.MODE.toUpperCase()}\n`;
    menuText += `│ 📊 *Commands:* ${commands.length}\n`;
    menuText += `╰─────────────────────\n\n`;

    for (const [catName, cmds] of Object.entries(categories)) {
      const header = `╭───「 *${catName.toUpperCase()}* 」`;
      menuText += `${header}\n`;
      for (const cmd of cmds) {
        const patternStr = typeof cmd.pattern === 'string' ? cmd.pattern : cmd.pattern.toString();
        menuText += `│ ⭓ \`${config.PREFIX}${patternStr}\` ${cmd.desc ? `_— ${cmd.desc}_` : ''}\n`;
      }
      menuText += `╰─────────────────────\n\n`;
    }

    menuText += `_Tip: Type ${config.PREFIX}ping or ${config.PREFIX}alive to test connection._`;

    await m.reply(menuText);
  }
);
