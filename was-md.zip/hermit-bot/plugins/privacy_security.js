const config = require('../config');
const { command } = require('../lib/plugins');
const { db, saveDb, markBotSent } = require('../lib/store');
const { parseMention } = require('../lib/functions');

// ============================================================================
// FEATURE #21: "Forwarded Many Times" Auto-Tag for Every Message You Type
// (.autofwd & .fwd)
// ============================================================================
command(
  {
    pattern: 'autofwd',
    alias: ['fakeforward', 'alwaysforward'],
    desc: 'Make every normal message you type appear as "Forwarded many times" (on / off / all / bot)',
    type: 'privacy',
    fromMe: true,
  },
  async (m, match) => {
    const arg = match.trim().toLowerCase();

    if (arg === 'on') {
      db.autoforward.enabled = true;
      db.autoforward.mode = 'all';
      saveDb();
      return await m.reply(
        `⏩ *Auto "Forwarded Many Times" ENABLED*\n` +
          `Every normal message you type will automatically appear with the *Forwarded many times* banner (Score: ${db.autoforward.score}).`
      );
    }

    if (arg === 'off') {
      db.autoforward.enabled = false;
      saveDb();
      return await m.reply('⚪ *Auto "Forwarded Many Times" DISABLED.*');
    }

    if (arg === 'all' || arg === 'bot') {
      db.autoforward.enabled = true;
      db.autoforward.mode = arg;
      saveDb();
      return await m.reply(
        `⏩ *Auto-Forward Mode set to:* \`${arg.toUpperCase()}\`\n` +
          `${arg === 'all' ? '• Replaces every normal message you type + bot replies' : '• Applies to bot replies only'}`
      );
    }

    await m.reply(
      `⏩ *"FORWARDED MANY TIMES" STATUS*\n\n` +
        `• *Status:* ${db.autoforward.enabled ? 'ENABLED ✅' : 'DISABLED ❌'}\n` +
        `• *Scope:* ${db.autoforward.mode === 'all' ? 'Every Message You Type + Bot Replies' : 'Bot Replies Only'}\n` +
        `• *Forwarding Score:* \`${db.autoforward.score}\` (⏩⏩ Forwarded many times)\n\n` +
        `*Commands:*\n` +
        `• \`.autofwd on\` — Enable for every message you type\n` +
        `• \`.autofwd off\` — Disable auto-forwarding\n` +
        `• \`.autofwd bot\` — Apply only to bot command replies\n` +
        `• \`.fwd <text>\` — Send a single message as "Forwarded many times"`
    );
  }
);

command(
  {
    pattern: 'fwd',
    alias: ['forward'],
    desc: 'Send any text or replied message/media with the "Forwarded many times" banner',
    type: 'privacy',
  },
  async (m, match, { sock }) => {
    const forwardContext = {
      isForwarded: true,
      forwardingScore: db.autoforward?.score || 999,
    };

    if (m.quoted && m.quoted.isMedia) {
      const buffer = await m.quoted.download();
      const mediaType = m.quoted.type.replace('Message', '');
      const payload = {
        [mediaType]: buffer,
        caption: match || m.quoted.body || '',
        contextInfo: forwardContext,
      };
      if (mediaType === 'audio') {
        payload.mimetype = 'audio/mp4';
        payload.ptt = true;
      }
      const sent = await sock.sendMessage(m.from, payload);
      if (sent?.key?.id) markBotSent(sent.key.id);
      return;
    }

    const text = match || m.quoted?.body;
    if (!text) {
      return await m.reply('⏩ Provide text or reply to a message: `.fwd Hello everyone!`');
    }

    const mentions = parseMention(text);
    const sent = await sock.sendMessage(m.from, {
      text,
      mentions,
      contextInfo: {
        ...forwardContext,
        mentionedJid: mentions,
      },
    });
    if (sent?.key?.id) markBotSent(sent.key.id);
  }
);

// ============================================================================
// FEATURE #1: Anti-ViewOnce Revealer (.vv)
// ============================================================================
command(
  {
    pattern: 'vv',
    alias: ['viewonce', 'reveal'],
    desc: 'Unlock and reveal View-Once image, video, or audio (use ".vv dm" to send to private chat)',
    type: 'privacy',
  },
  async (m, match, { sock }) => {
    if (!m.quoted || !m.quoted.isMedia) {
      return await m.reply('👁️ Reply to a *View-Once* photo, video, or voice note with `.vv` (or `.vv dm` to send to your DM).');
    }

    await m.react('🔓');
    try {
      const buffer = await m.quoted.download();
      const targetJid = match.trim().toLowerCase() === 'dm' ? m.sender : m.from;
      const caption = `🔓 *Revealed View-Once Media*\n• *From:* @${m.quoted.senderNumber}\n• *Device:* ${m.quoted.device}${
        m.quoted.body ? `\n• *Caption:* ${m.quoted.body}` : ''
      }`;

      if (m.quoted.type === 'imageMessage') {
        await sock.sendMessage(targetJid, { image: buffer, caption, mentions: [m.quoted.sender] }, { quoted: m });
      } else if (m.quoted.type === 'videoMessage') {
        await sock.sendMessage(targetJid, { video: buffer, caption, mentions: [m.quoted.sender] }, { quoted: m });
      } else if (m.quoted.type === 'audioMessage') {
        await sock.sendMessage(targetJid, { audio: buffer, mimetype: 'audio/mp4', ptt: true }, { quoted: m });
      } else {
        await m.reply('⚠️ Unsupported View-Once media type.');
      }
    } catch (err) {
      await m.reply(`❌ Failed to unlock View-Once media: ${err.message}`);
    }
  }
);

// ============================================================================
// FEATURE #2: Anti-Delete Recovery to Owner's Personal DM (.antidelete)
// ============================================================================
command(
  {
    pattern: 'antidelete',
    alias: ['antirevoke'],
    desc: 'Configure automatic recovery of deleted messages & media to Owner Personal DM',
    type: 'privacy',
    fromMe: true,
  },
  async (m, match) => {
    const [sub, ...rest] = match.trim().split(/ +/);
    const arg = (sub || '').toLowerCase();

    if (arg === 'on') {
      db.antidelete.enabled = true;
      saveDb();
      return await m.reply(
        `🛡️ *Anti-Delete Enabled*\n• *Destination:* ${
          db.antidelete.target === 'dm'
            ? `Owner Personal DM (+${db.antidelete.ownerDmNumber || config.OWNER_NUMBER[0]})`
            : 'Same Chat'
        }`
      );
    }
    if (arg === 'off') {
      db.antidelete.enabled = false;
      saveDb();
      return await m.reply('⚪ *Anti-Delete Disabled.*');
    }
    if (arg === 'dm' || arg === 'chat') {
      db.antidelete.enabled = true;
      db.antidelete.target = arg;
      saveDb();
      return await m.reply(
        `🛡️ *Anti-Delete destination updated to:* *${
          arg === 'dm'
            ? `Owner Personal DM (+${db.antidelete.ownerDmNumber || config.OWNER_NUMBER[0]})`
            : 'Same Chat'
        }*`
      );
    }
    if (arg === 'setnum' && rest[0]) {
      const cleanNum = rest[0].replace(/[^0-9]/g, '');
      db.antidelete.ownerDmNumber = cleanNum;
      db.antidelete.target = 'dm';
      db.antidelete.enabled = true;
      saveDb();
      return await m.reply(`✅ *Anti-Delete Personal DM number set to:* \`+${cleanNum}\``);
    }

    const activeOwnerNum = db.antidelete.ownerDmNumber || config.OWNER_NUMBER[0];
    await m.reply(
      `🛡️ *ANTI-DELETE RECOVERY SETTINGS*\n\n` +
        `• *Status:* ${db.antidelete.enabled ? 'ENABLED ✅' : 'DISABLED ❌'}\n` +
        `• *Mode:* ${db.antidelete.target === 'dm' ? 'Owner Personal DM 📩' : 'Same Chat 💬'}\n` +
        `• *Owner DM Number:* \`+${activeOwnerNum}\`\n\n` +
        `*Commands:*\n` +
        `• \`.antidelete dm\` — Send deleted texts & media to Owner's personal DM\n` +
        `• \`.antidelete setnum 919876543210\` — Change Owner DM number\n` +
        `• \`.antidelete chat\` — Resend deleted messages in the same chat\n` +
        `• \`.antidelete off\` — Turn off Anti-Delete`
    );
  }
);

// ============================================================================
// FEATURE #10: WhatsApp Status Saver (.save)
// ============================================================================
command(
  {
    pattern: 'save',
    alias: ['status', 'downloadstatus'],
    desc: 'Download a replied WhatsApp Status photo or video directly to your DM',
    type: 'privacy',
  },
  async (m, _, { sock }) => {
    if (!m.quoted || !m.quoted.isMedia) {
      return await m.reply('📥 Reply to any WhatsApp Status or media message with `.save` to download it.');
    }

    await m.react('📥');
    try {
      const buffer = await m.quoted.download();
      const caption = `📥 *Saved Media*\n• *From:* @${m.quoted.senderNumber}${
        m.quoted.body ? `\n• *Caption:* ${m.quoted.body}` : ''
      }`;

      if (m.quoted.type === 'imageMessage') {
        await sock.sendMessage(m.sender, { image: buffer, caption, mentions: [m.quoted.sender] }, { quoted: m });
      } else if (m.quoted.type === 'videoMessage') {
        await sock.sendMessage(m.sender, { video: buffer, caption, mentions: [m.quoted.sender] }, { quoted: m });
      } else if (m.quoted.type === 'audioMessage') {
        await sock.sendMessage(m.sender, { audio: buffer, mimetype: 'audio/mp4' }, { quoted: m });
      }
      if (m.isGroup) await m.reply('✅ Sent to your private DM!');
    } catch (err) {
      await m.reply('❌ Could not download status media.');
    }
  }
);

// ============================================================================
// FEATURE #16: Device Fingerprinter (.msginfo) & Zero-Width Spoiler (.readmore)
// ============================================================================
command(
  {
    pattern: 'msginfo',
    alias: ['device', 'whois'],
    desc: 'Inspect a message stanza ID to detect sender OS (iOS/Android/Web) and metadata',
    type: 'privacy',
  },
  async (m) => {
    const target = m.quoted || m;
    const info =
      `🔍 *MESSAGE STANZA INSPECTOR*\n\n` +
      `• *Sender:* @${target.senderNumber}\n` +
      `• *Client OS:* ${target.device}\n` +
      `• *Message ID:* \`${target.id}\`\n` +
      `• *Content Type:* \`${target.type}\`\n` +
      `• *View-Once:* ${target.isViewOnce ? 'Yes 🔒' : 'No'}`;

    await m.reply(info, { mentions: [target.sender] });
  }
);

command(
  {
    pattern: 'readmore',
    alias: ['spoiler', 'rm'],
    desc: 'Create an expandable "Read More" spoiler message (.readmore Visible | Hidden)',
    type: 'privacy',
  },
  async (m, match) => {
    if (!match.includes('|')) {
      return await m.reply('⚠️ Usage: `.readmore Visible Header | Hidden Spoiler Text`');
    }
    const [front, ...rest] = match.split('|');
    const back = rest.join('|');
    const readMoreChar = String.fromCharCode(8206).repeat(4001);
    await m.reply(`${front.trim()}${readMoreChar}${back.trim()}`);
  }
);
