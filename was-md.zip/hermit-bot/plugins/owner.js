const util = require('util');
const config = require('../config');
const { command } = require('../lib/plugins');

command(
  {
    pattern: 'eval',
    alias: ['>'],
    desc: 'Evaluate JavaScript code directly on bot instance',
    type: 'owner',
    fromMe: true,
  },
  async (m, match, { sock }) => {
    if (!match) return await m.reply('Provide code to evaluate: `.eval return 2 + 2`');

    try {
      let evaled = await eval(`(async () => { ${match} })()`);
      if (typeof evaled !== 'string') evaled = util.inspect(evaled, { depth: 1 });
      await m.reply(`*Result:*\n\`\`\`js\n${evaled}\n\`\`\``);
    } catch (err) {
      await m.reply(`*Error:*\n\`\`\`js\n${err.message || err}\n\`\`\``);
    }
  }
);

command(
  {
    pattern: 'mode',
    desc: 'Toggle bot operational mode between public and private',
    type: 'owner',
    fromMe: true,
  },
  async (m, match) => {
    const targetMode = match.toLowerCase();
    if (targetMode === 'public' || targetMode === 'private') {
      config.MODE = targetMode;
      return await m.reply(`✅ Bot mode updated to: *${config.MODE.toUpperCase()}*`);
    }

    await m.reply(
      `Current mode: *${config.MODE.toUpperCase()}*\n\nUsage:\n- \`.mode public\` (everyone can use)\n- \`.mode private\` (owner only)`
    );
  }
);

command(
  {
    pattern: 'restart',
    alias: ['reboot'],
    desc: 'Restart bot process',
    type: 'owner',
    fromMe: true,
  },
  async (m) => {
    await m.reply('🔄 Restarting bot daemon...');
    process.exit(0);
  }
);

command(
  {
    pattern: 'broadcast',
    alias: ['bc'],
    desc: 'Broadcast announcement to all groups the bot is in',
    type: 'owner',
    fromMe: true,
  },
  async (m, match, { sock }) => {
    if (!match) return await m.reply('Please provide broadcast message: `.bc Hello everyone!`');

    const getGroups = await sock.groupFetchAllParticipating();
    const groupJids = Object.keys(getGroups);

    await m.reply(`📡 Sending broadcast to ${groupJids.length} groups...`);

    let sent = 0;
    for (const jid of groupJids) {
      try {
        await sock.sendMessage(jid, {
          text: `📢 *BOT BROADCAST*\n\n${match}\n\n_— Sent by ${config.OWNER_NAME}_`,
        });
        sent++;
      } catch (e) {
        // Skip failed groups
      }
    }

    await m.reply(`✅ Broadcast successfully delivered to ${sent}/${groupJids.length} groups.`);
  }
);

command(
  {
    pattern: 'block',
    desc: 'Block a user on WhatsApp',
    type: 'owner',
    fromMe: true,
  },
  async (m, match, { sock }) => {
    let target = m.quoted ? m.quoted.sender : m.mentionedJid?.[0];
    if (!target && match) {
      target = match.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
    }

    if (!target) return await m.reply('Reply to or mention the user you want to block.');

    await sock.updateBlockStatus(target, 'block');
    await m.reply(`🚫 Blocked @${target.split('@')[0]}`, { mentions: [target] });
  }
);

command(
  {
    pattern: 'unblock',
    desc: 'Unblock a user on WhatsApp',
    type: 'owner',
    fromMe: true,
  },
  async (m, match, { sock }) => {
    let target = m.quoted ? m.quoted.sender : m.mentionedJid?.[0];
    if (!target && match) {
      target = match.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
    }

    if (!target) return await m.reply('Reply to or mention the user you want to unblock.');

    await sock.updateBlockStatus(target, 'unblock');
    await m.reply(`✅ Unblocked @${target.split('@')[0]}`, { mentions: [target] });
  }
);

command(
  {
    pattern: 'join',
    desc: 'Join a group via invite link',
    type: 'owner',
    fromMe: true,
  },
  async (m, match, { sock }) => {
    if (!match) return await m.reply('Provide group link: `.join https://chat.whatsapp.com/xxx`');
    const code = match.split('https://chat.whatsapp.com/')[1];
    if (!code) return await m.reply('Invalid invite link format.');

    try {
      await sock.groupAcceptInvite(code);
      await m.reply('✅ Successfully joined group!');
    } catch (err) {
      await m.reply(`❌ Failed to join group: ${err.message}`);
    }
  }
);
