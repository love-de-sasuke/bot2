# Hermit-MD WhatsApp Bot — 21 Unique Features Edition (Baileys Multi-Device)

A modular, high-performance WhatsApp Multi-Device bot modeled after **Hermit-MD** and built on **[@whiskeysockets/baileys](https://github.com/WhiskeySockets/Baileys)** with **21 unique, built-in power features** covering automatic **"Forwarded many times"** message transformation, **Owner Personal DM Anti-Delete recovery**, privacy tools, live message editing, FFmpeg audio DSP filters, WebP EXIF injection, group security shields, and chat mini-games.

## 🌟 The 21 Unique Features

| # | Feature Name | Trigger / Command | How It Works Under the Hood |
| :--- | :--- | :--- | :--- |
| **1** | **Anti-ViewOnce Revealer** | `.vv` / `.vv dm` | Strips `viewOnceMessageV2` flags from quoted media and re-uploads the decrypted photo, video, or voice note to chat or directly to your DM. |
| **2** | **Anti-Delete Recovery to Owner Personal DM** | `.antidelete dm` / `.antidelete setnum <num>` | Caches incoming texts **and media** (photos, videos, voice notes, stickers) in `lib/store.js` and intercepts `protocolMessage` revoke events (`type === 0`), forwarding the deleted message + sender/group details straight to the **Owner's Personal DM** (`OWNER_NUMBER`). |
| **3** | **Smart AFK System** | `.afk [reason]` | Automatically replies when anyone tags or quotes you with your custom reason and elapsed time away, then auto-clears your AFK status the moment you speak again. |
| **4** | **Anti-Link & 3-Strike Shield** | `.antilink on/warn/kick` | Detects unauthorized `chat.whatsapp.com` invite links in real time, deletes the offending message (`sock.sendMessage(jid, { delete })`), tracks 3-strike warnings, and kicks repeat offenders. |
| **5** | **Audio DSP & Voice Changer** | `.bass`, `.nightcore`, `.slow`, `.deep`, `.robot`, `.reverse` | Pipes replied voice notes through custom `fluent-ffmpeg` audio filter graphs (`asetrate`, `afftfilt`, `equalizer`) and returns a playable PTT voice note. |
| **6** | **Quote-Chat Bubble Maker** | `.qc <text>` | Renders a realistic WhatsApp message bubble sticker featuring the user's live profile picture, display name, and text. |
| **7** | **Self-Destructing Vanish Mode** | `.vanish <sec> <msg>` | Sends a message with a live in-place countdown timer that automatically deletes itself for everyone when the timer hits `0s`. |
| **8** | **Live Message Edit Animations** | `.type <text>`, `.hack` | Uses Baileys' `edit: sent.key` protocol to animate a typewriter effect or terminal sequence inside a single WhatsApp bubble. |
| **9** | **Native Poll Builder** | `.poll Q \| Opt1 \| Opt2` | Dispatches native interactive WhatsApp polls (`poll: { name, values, selectableCount }`) from a single text command. |
| **10** | **Status Auto-Reactor & Saver** | `.save` + Auto-View | Automatically marks `status@broadcast` stories as viewed, reacts with your chosen emoji (`💚`), and downloads any status story when you reply `.save`. |
| **11** | **Custom WebP EXIF Sticker Stealer** | `.take Pack \| Author` | Injects custom RIFF `EXIF` metadata chunks (`lib/exif.js`) into any sticker in pure Node.js so tapping the sticker shows your custom Pack Name and Author. |
| **12** | **Anti-Spam Flood Limiter** | `.antispam on/off` | Uses a sliding-window timestamp tracker (`lib/store.js`) to detect and warn users who flood more than 6 messages within 4 seconds. |
| **13** | **In-Chat Wordle Mini-Game** | `.wordle`, `.guess <word>` | Stateful 5-letter Wordle engine right inside WhatsApp groups with visual emoji grid feedback (`🟩🟨⬛`). |
| **14** | **Bulk Group VCF Contact Exporter** | `.exportvcf`, `.vcard` | Packages every participant in a WhatsApp group into a single downloadable `.vcf` file so admins can import all group contacts in one tap. |
| **15** | **Persistent Todo & Live Reminders** | `.todo`, `.remind 15m Task` | JSON-backed personal task pinboard (`.todo add/done/clear`) paired with live countdown alerts that mention you when time is up. |
| **16** | **Stanza OS Fingerprinter & Spoiler** | `.msginfo`, `.readmore` | Analyzes WhatsApp stanza ID patterns to detect if a user is on **iOS 🍎, Android 📱, Web 💻, or Desktop 🖥️**, plus generates expandable zero-width "Read More" spoilers. |
| **17** | **Custom Keyword Auto-Filters** | `.filter add hi \| Hello!` | Per-chat custom trigger dictionary that automatically replies whenever a member sends a matching keyword or phrase. |
| **18** | **Welcome & Goodbye Group Greeter** | `.welcome on`, `.goodbye on` | Listens to `group-participants.update` events to greet joining or departing members with live member counts. |
| **19** | **Disposable TempMail Inbox** | `.tempmail`, `.checkmail` | Generates a working disposable email address and fetches incoming verification emails and OTP codes directly inside WhatsApp. |
| **20** | **Group Activity Leaderboard & Ghost Finder** | `.topchat`, `.inactive` | Tracks per-member message volume to rank the top 15 most active talkers (`🥇🥈🥉`) and identify silent 0-message ghost members. |
| **21** | **"Forwarded Many Times" Auto-Modifier** | `.autofwd on/off/all/bot` & `.fwd <text>` | Intercepts every normal message you type (`m.fromMe`) and bot replies, injecting `contextInfo: { isForwarded: true, forwardingScore: 999 }` so all your messages appear with the `⏩⏩ Forwarded many times` tag! |

## 📁 Project Architecture

```text
hermit-bot/
├── config.js                  # Environment settings, AUTO_FAKE_FORWARD, ANTI_DELETE_TARGET, OWNER_NUMBER
├── index.js                   # Socket connection, Auto-Forward interceptor & Owner DM Anti-Delete hook
├── package.json               # Dependencies (@whiskeysockets/baileys, pino, fluent-ffmpeg, axios)
├── ecosystem.config.js        # PM2 process configuration for 24/7 background hosting
├── Dockerfile                 # Container definition with FFmpeg & WebP pre-installed
├── .env.example               # Environment variables template
├── lib/
│   ├── serialize.js           # Unwraps ViewOnce/Ephemeral, injects forwardingScore: 999, adds .edit() & .delete()
│   ├── store.js               # Persistent JSON database + rolling Anti-Delete cache & botSentIds loop guard
│   ├── exif.js                # Pure Node.js RIFF WebP EXIF metadata injector for .take
│   ├── plugins.js             # Hermit-style command() decorator, plugin loader & permission router
│   └── functions.js           # Runtime calculators, byte formatters, HTTP & mention helpers
└── plugins/
    ├── privacy_security.js    # Features #21 (.autofwd, .fwd), #1 (.vv), #2 (.antidelete), #10 (.save), #16 (.msginfo, .readmore)
    ├── group.js               # Features #4 (.antilink), #9 (.poll), #12 (.antispam), #14 (.exportvcf), #18 (.welcome), #20 (.topchat, .inactive) + moderation
    ├── media.js               # Features #5 (6 audio effects), #6 (.qc), #11 (.take) + .sticker
    ├── automation_fun.js      # Features #3 (.afk), #7 (.vanish, .schedule), #8 (.type, .hack), #13 (.wordle), #15 (.todo, .remind), #17 (.filter)
    ├── tools.js               # Feature #19 (.tempmail, .checkmail) + .calc, .qr, .shorturl
    ├── general.js             # .ping, .alive, .uptime, and dynamic categorized .menu
    └── owner.js               # .eval, .mode (public/private), .broadcast, .restart, .block, .join
```

## 🚀 Quick Start & Installation

### 1. Prerequisites
- **Node.js**: `v18.0.0` or higher
- **FFmpeg**: Required for audio voice-changer filters and WebP sticker conversion
  - Ubuntu/Debian: `sudo apt update && sudo apt install -y ffmpeg webp`
  - macOS: `brew install ffmpeg`
  - Termux (Android): `pkg install nodejs-lts ffmpeg git`

### 2. Install & Configure
```bash
cd hermit-bot
npm install
cp .env.example .env
```

Edit `.env` with your settings:
```env
PAIRING_CODE=true
PHONE_NUMBER=919876543210
BOT_NAME=Hermit-MD
OWNER_NAME=Adithyan
OWNER_NUMBER=919876543210
PREFIX=.
MODE=public

# Make every message you type appear as "Forwarded many times"
AUTO_FAKE_FORWARD=true
FORWARDING_SCORE=999

# Send all deleted messages & media to Owner's Personal DM
ANTI_DELETE=true
ANTI_DELETE_TARGET=dm

AUTO_STATUS_READ=true
AUTO_STATUS_REACT=true
STATUS_EMOJI=💚
```

### 3. Start & Link via 8-Digit Pairing Code
```bash
npm start
```
1. An 8-digit pairing code (e.g. `ABCD-1234`) will appear in your terminal after 3 seconds.
2. On your phone, open **WhatsApp > Settings > Linked Devices > Link with phone number instead** and enter the code.

## 🛠️ Complete Command Catalog

| Category | Command | Description | Access Level |
| :--- | :--- | :--- | :--- |
| **Privacy** | `.autofwd <on/off/all/bot>` | Make every message you type show "Forwarded many times" | Owner |
| **Privacy** | `.fwd <text>` | Manually send text or replied media as "Forwarded many times" | Anyone |
| **Privacy** | `.antidelete <dm/chat/off>` | Recover deleted texts & media to Owner's Personal DM | Owner |
| **Privacy** | `.antidelete setnum <num>` | Set custom Owner Personal DM phone number for deleted msgs | Owner |
| **Privacy** | `.vv [dm]` | Unlock View-Once photo, video, or voice note | Anyone |
| **Privacy** | `.save` | Download a replied WhatsApp Status story to your DM | Anyone |
| **Privacy** | `.msginfo` / `.device` | Fingerprint sender OS (iOS/Android/Web) & stanza ID | Anyone |
| **Privacy** | `.readmore <front> \| <back>` | Create an expandable "Read More" spoiler message | Anyone |
| **Automation** | `.afk [reason]` | Set AFK status with auto-responder & elapsed timer | Anyone |
| **Automation** | `.vanish <sec> <msg>` | Send a live countdown self-destructing message | Anyone |
| **Automation** | `.schedule <10s/5m/1h> <msg>` | Schedule delayed message delivery | Anyone |
| **Automation** | `.type <text>` | Live typewriter message edit animation | Anyone |
| **Automation** | `.hack [@user]` | Live-edited terminal simulation in a single bubble | Anyone |
| **Automation** | `.wordle` / `.guess <word>` | Play 5-letter Wordle with emoji feedback | Anyone |
| **Automation** | `.todo <add/list/done/clear>` | Manage your personal persistent task pinboard | Anyone |
| **Automation** | `.remind <10m> <task>` | Set a live timer alert that tags you when time is up | Anyone |
| **Automation** | `.filter <add/del/list>` | Configure custom auto-reply keyword triggers | Anyone |
| **Media & DSP** | `.bass` / `.nightcore` / `.slow` | Apply FFmpeg audio filters to a replied voice note | Anyone |
| **Media & DSP** | `.deep` / `.robot` / `.reverse` | Transform voice pitch, vocoder, or reverse playback | Anyone |
| **Media & DSP** | `.qc <text>` | Generate a realistic quote-chat bubble sticker | Anyone |
| **Media & DSP** | `.take <Pack> \| <Author>` | Rewrite sticker EXIF Pack Name & Author metadata | Anyone |
| **Media & DSP** | `.sticker` / `.s` | Convert image or short video clip to WebP sticker | Anyone |
| **Group Shield** | `.antilink <on/off/warn/kick>` | Auto-delete group links with 3-strike auto-kick | Group Admin |
| **Group Shield** | `.antispam <on/off>` | Toggle sliding-window flood limiter (>6 msgs/4s) | Group Admin |
| **Group Shield** | `.poll Q \| Opt1 \| Opt2` | Launch a native interactive WhatsApp poll | Anyone |
| **Group Shield** | `.vcard [@user]` | Generate a savable contact card for a member | Anyone |
| **Group Shield** | `.exportvcf` | Export all group members into a downloadable `.vcf` file | Group Admin |
| **Group Shield** | `.welcome <on/off>` | Toggle automatic welcome messages for new members | Group Admin |
| **Group Shield** | `.goodbye <on/off>` | Toggle automatic farewell messages when members leave | Group Admin |
| **Group Shield** | `.topchat` / `.leaderboard` | Rank the top 15 most active group members | Group Member |
| **Group Shield** | `.inactive` / `.ghosts` | List silent group members with 0 messages | Group Admin |
| **Group Shield** | `.tagall` / `.hidetag` | Mention all group members visibly or invisibly | Group Admin |
| **Group Shield** | `.kick` / `.promote` / `.demote` | Manage group membership and admin roles | Group Admin |
| **Tools** | `.tempmail` / `.checkmail` | Generate disposable email & read incoming OTP emails | Anyone |
| **Tools** | `.calc <expr>` | Evaluate mathematical expressions | Anyone |
| **Tools** | `.qr <text>` / `.shorturl <url>` | Generate QR codes or shorten long URLs | Anyone |
| **General** | `.menu` / `.ping` / `.alive` | View categorized command menu, latency, and system info | Anyone |
| **Owner** | `.eval` / `.mode` / `.bc` | Run JS code, switch public/private mode, or broadcast | Owner |
